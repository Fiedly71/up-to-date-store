export const products = [
  {
    id: 1,
    name: "USB-C Adapter",
    image: "/adaptertypec.jpg",
  },
  {
    id: 2,
    name: "Premium USB-C Cable",
    image: "/cabletypec.jpg",
  },
  {
    id: 3,
    name: "Ultrasonic Humidifier",
    image: "/humidifier.jpg",
  },
  {
    id: 4,
    name: "LED Smart Light",
    image: "/led.jpg",
  },
  {
    id: 5,
    name: "Phone Light Ring",
    image: "/phonelight1.jpg",
  },
  {
    id: 6,
    name: "Smart Projector",
    image: "/smartprojecteur.jpg",
  },
  {
    id: 7,
    name: "Sunset LED Light",
    image: "/sunsetlight.jpg",
  },
  {
    id: 8,
    name: "Smart Watch",
    image: "/smartwatch.jpg",
  },
  {
    id: 9,
    name: "Premium Phone Light",
    image: "/phonelight2.jpg",
  },
];
